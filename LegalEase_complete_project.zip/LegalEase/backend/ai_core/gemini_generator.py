import os
from dotenv import load_dotenv

load_dotenv()

class GeminiDocumentGenerator:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY", "").strip()
        self.model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        self._client = None

    def _get_client(self):
        if not self.api_key:
            return None
        if self._client is None:
            try:
                from google import genai
                self._client = genai.Client(api_key=self.api_key)
            except Exception as exc:
                raise RuntimeError(
                    "Google Gemini SDK could not be initialized. "
                    "Install requirements and check GEMINI_API_KEY."
                ) from exc
        return self._client

    @staticmethod
    def _demo_document(document_type, parties, terms, effective_date, jurisdiction, language):
        term_lines = [x.strip() for x in terms.split(";") if x.strip()]
        bullets = "\n".join(f"- {x}" for x in term_lines)
        return f"""{document_type.upper()}

Effective Date: {effective_date}
Jurisdiction: {jurisdiction}
Language: {language}

PARTIES
{parties}

1. PURPOSE
This document records the understanding between the parties identified above for the purpose described by the selected document type.

2. TERMS AND CONDITIONS
{bullets}

3. RESPONSIBILITIES
Each party shall perform the responsibilities agreed between the parties and shall comply with the applicable terms stated in this document.

4. CONFIDENTIALITY
Where confidential information is exchanged, each party shall use reasonable care to protect it and shall not disclose it except as permitted by the agreement or applicable law.

5. TERM AND TERMINATION
The parties shall follow the agreed duration and termination conditions. Any notice requirements should be stated clearly before execution.

6. GOVERNING LAW
The parties should specify the governing law and jurisdiction appropriate to their circumstances.

7. SIGNATURES
Party 1: ______________________________

Party 2: ______________________________

Date: ______________________________

NOTE: This is a local demo draft because no Gemini API key is configured. It must be reviewed for completeness and applicable law before use.
"""

    def generate_document(self, document_type, parties, terms, effective_date,
                          jurisdiction="Not specified", language="English",
                          include_summary=True):
        client = self._get_client()
        if client is None:
            return self._demo_document(document_type, parties, terms, effective_date, jurisdiction, language), True

        prompt = f"""You are a careful legal-document drafting assistant.
Draft a professional, editable {document_type} in {language}.

User inputs:
- Parties: {parties}
- Terms/conditions: {terms}
- Effective date: {effective_date}
- Jurisdiction: {jurisdiction}

Requirements:
1. Use clear formal legal language.
2. Do not invent names, dates, amounts, addresses, laws, or facts not supplied.
3. Preserve all user-provided terms.
4. Include a title and logical numbered sections.
5. Include signature blocks where appropriate.
6. If jurisdiction is unspecified, do not claim a specific law applies.
7. If a requested legal requirement depends on local law, mark it as [REVIEW REQUIRED] rather than inventing it.
8. Return only the document text, without Markdown code fences.
{"9. After the document, include a short PLAIN-LANGUAGE SUMMARY section." if include_summary else ""}"""

        try:
            response = client.models.generate_content(model=self.model, contents=prompt)
            text = getattr(response, "text", None)
            if not text:
                raise RuntimeError("Gemini returned an empty response.")
            return text.strip(), False
        except Exception as exc:
            raise RuntimeError(f"Gemini generation failed: {exc}") from exc
