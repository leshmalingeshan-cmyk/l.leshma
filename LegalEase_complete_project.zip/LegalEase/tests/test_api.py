import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_generate_demo_mode():
    response = client.post("/generate", json={
        "document_type": "Non-Disclosure Agreement",
        "parties": "A (Disclosing Party), B (Receiving Party)",
        "terms": "Keep information confidential; Return information on termination",
        "effective_date": "October 1, 2026"
    })
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert len(data["content"]) > 100
