from pydantic import BaseModel, Field, field_validator

class DocumentRequest(BaseModel):
    document_type: str = Field(..., min_length=2, max_length=120)
    parties: str = Field(..., min_length=2, max_length=2000)
    terms: str = Field(..., min_length=2, max_length=8000)
    effective_date: str = Field(..., min_length=2, max_length=100)
    jurisdiction: str = Field(default="Not specified", max_length=200)
    language: str = Field(default="English", max_length=50)
    include_summary: bool = True

    @field_validator("document_type", "parties", "terms", "effective_date")
    @classmethod
    def strip_fields(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Field cannot be empty.")
        return value

class DocumentResponse(BaseModel):
    success: bool
    document_type: str
    content: str
    model: str
    demo_mode: bool = False
