from fastapi import APIRouter, HTTPException
from .models import DocumentRequest, DocumentResponse
from .ai_core.gemini_generator import GeminiDocumentGenerator

router = APIRouter()
generator = GeminiDocumentGenerator()

@router.post("/generate", response_model=DocumentResponse)
def generate_document(request: DocumentRequest):
    try:
        content, demo_mode = generator.generate_document(
            request.document_type, request.parties, request.terms,
            request.effective_date, request.jurisdiction,
            request.language, request.include_summary
        )
        return DocumentResponse(
            success=True, document_type=request.document_type,
            content=content, model=generator.model, demo_mode=demo_mode
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Unexpected server error: {exc}")
