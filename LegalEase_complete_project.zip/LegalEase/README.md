# LegalEase — AI-Powered Legal Document Generator

LegalEase is a Streamlit + FastAPI application that uses Google Gemini to draft editable legal documents and export them as TXT, DOCX, and PDF.

## Features
- Employment contracts, NDAs, lease agreements, offer letters, and custom agreements
- Gemini-powered drafting
- Editable generated text
- DOCX/PDF/TXT export
- Optional logo/branding
- Terms table in DOCX
- API health check and `/generate` endpoint
- Local demo mode when no Gemini API key is configured

## Project structure
```text
LegalEase/
├── backend/
│   ├── main.py
│   ├── routes.py
│   ├── models.py
│   ├── ai_core/gemini_generator.py
│   └── utils/document_export.py
├── frontend/app.py
├── assets/
├── tests/test_api.py
├── .env.example
├── requirements.txt
└── README.md
```

## Windows setup
```powershell
cd LegalEase
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```
Edit `.env` and set `GEMINI_API_KEY`.

Start backend:
```powershell
uvicorn backend.main:app --reload --port 8000
```

In a second terminal:
```powershell
cd LegalEase
.venv\Scripts\activate
streamlit run frontend/app.py
```

Open the Streamlit URL shown in the terminal, normally `http://localhost:8501`.

## Linux/macOS
```bash
cd LegalEase
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn backend.main:app --reload --port 8000
```
Then in another terminal:
```bash
streamlit run frontend/app.py
```

## API example
```bash
curl -X POST http://127.0.0.1:8000/generate   -H "Content-Type: application/json"   -d '{"document_type":"Non-Disclosure Agreement","parties":"Jane Doe (Disclosing Party), TechNova Inc. (Receiving Party)","terms":"Confidential information; No unauthorized disclosure; Return information on termination","effective_date":"2026-10-01"}'
```

## Test
With dependencies installed:
```bash
pytest -q
```

## Important
LegalEase generates draft legal text. It is not a substitute for review by a qualified lawyer, and the generated document should be checked for jurisdiction-specific requirements before signing or relying on it.
