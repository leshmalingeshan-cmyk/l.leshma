import html
import io
import re
from datetime import datetime
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, Inches
from fpdf import FPDF

def sanitize_text(text: str) -> str:
    replacements = {"“": '"', "”": '"', "‘": "'", "’": "'", "–": "-", "—": "-", "•": "-"}
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.encode("latin-1", "replace").decode("latin-1")

def _lines(text):
    return [line.rstrip() for line in text.replace("\r\n", "\n").split("\n")]

def format_html_preview(text: str) -> str:
    safe = html.escape(text)
    safe = re.sub(r"(?m)^([A-Z][A-Z0-9 &:/(),.-]{3,})$", r"<h3>\1</h3>", safe)
    safe = safe.replace("\n", "<br>")
    return f'<div class="legal-preview">{safe}</div>'

def format_docx(text: str, doc_type: str, logo_bytes: bytes | None = None) -> bytes:
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(0.7)
    sec.bottom_margin = Inches(0.7)
    sec.left_margin = Inches(0.85)
    sec.right_margin = Inches(0.85)

    if logo_bytes:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run()
        run.add_picture(io.BytesIO(logo_bytes), width=Inches(1.1))

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = title.add_run(doc_type.upper())
    r.bold = True
    r.font.name = "Times New Roman"
    r.font.size = Pt(16)

    for line in _lines(text):
        line = line.strip()
        if not line:
            doc.add_paragraph()
            continue
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(line)
        r.font.name = "Times New Roman"
        r.font.size = Pt(11)
        if re.match(r"^(\d+\.|[A-Z][A-Z0-9 &:/(),.-]{3,})$", line):
            r.bold = True

    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run(f"LegalEase | Generated {datetime.now():%Y-%m-%d} | Draft for review").font.size = Pt(8)

    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()

class LegalPDF(FPDF):
    def __init__(self, logo_bytes=None):
        super().__init__()
        self.logo_bytes = logo_bytes
    def header(self):
        if self.logo_bytes:
            try:
                self.image(self.logo_bytes, x=95, y=8, w=20)
                self.set_y(30)
            except Exception:
                self.set_y(12)
        else:
            self.set_y(12)
        self.set_font("Helvetica", "B", 10)
        self.cell(0, 8, "LegalEase", align="C")
        self.ln(10)
    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "", 8)
        self.cell(0, 8, f"LegalEase | Page {self.page_no()} | Draft for review", align="C")

def format_pdf(text: str, doc_type: str, logo_bytes: bytes | None = None) -> bytes:
    pdf = LegalPDF(logo_bytes)
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.multi_cell(0, 9, sanitize_text(doc_type.upper()), align="C")
    pdf.ln(4)
    for line in _lines(text):
        line = sanitize_text(line.strip())
        if not line:
            pdf.ln(3)
            continue
        is_heading = bool(re.match(r"^(\d+\.|[A-Z][A-Z0-9 &:/(),.-]{3,})$", line))
        pdf.set_font("Helvetica", "B" if is_heading else "", 11 if is_heading else 10)
        pdf.multi_cell(0, 6, line)
        pdf.ln(1)
    return bytes(pdf.output())
