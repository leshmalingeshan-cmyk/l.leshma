import os
import requests
import streamlit as st
from dotenv import load_dotenv
from backend.utils.document_export import format_docx, format_pdf, format_html_preview

load_dotenv()

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")
BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

st.markdown("""
<style>
.main-title {text-align:center;font-size:42px;font-weight:700;margin-bottom:0}
.subtitle {text-align:center;color:#777;margin-bottom:28px}
.legal-preview {background:#111827;color:#f3f4f6;padding:24px;border-radius:14px;
                max-height:620px;overflow-y:auto;line-height:1.65;font-family:Georgia,serif}
.legal-preview h3 {color:#fff;margin-top:18px}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-title">⚖️ LegalEase</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">AI-Powered Legal Document Generator</div>', unsafe_allow_html=True)

if "document" not in st.session_state:
    st.session_state.document = ""

with st.sidebar:
    st.header("Document Details")
    document_type = st.selectbox(
        "Document Type",
        ["Employment Contract", "Non-Disclosure Agreement", "Lease Agreement",
         "Employment Offer Letter", "Service Agreement", "Freelance Work Contract",
         "Partnership Agreement", "Custom Agreement"]
    )
    parties = st.text_area("Parties Involved", placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)")
    terms = st.text_area("Terms & Conditions", placeholder="Payment within 30 days; Confidentiality; 15-day termination notice")
    effective_date = st.text_input("Effective Date", placeholder="October 1, 2026")
    jurisdiction = st.text_input("Jurisdiction (optional)", value="Not specified")
    language = st.selectbox("Language", ["English", "Simple English"])
    include_summary = st.checkbox("Include plain-language summary", value=True)
    logo = st.file_uploader("Optional logo", type=["png", "jpg", "jpeg"])

    if st.button("Generate Document", type="primary", use_container_width=True):
        if not all([parties.strip(), terms.strip(), effective_date.strip()]):
            st.error("Please complete parties, terms, and effective date.")
        else:
            payload = {
                "document_type": document_type, "parties": parties, "terms": terms,
                "effective_date": effective_date, "jurisdiction": jurisdiction,
                "language": language, "include_summary": include_summary
            }
            try:
                with st.spinner("Generating your document..."):
                    response = requests.post(f"{BACKEND_URL}/generate", json=payload, timeout=120)
                if response.ok:
                    data = response.json()
                    st.session_state.document = data["content"]
                    st.session_state.model = data.get("model", "")
                    st.session_state.demo_mode = data.get("demo_mode", False)
                    st.success("Document generated.")
                else:
                    try:
                        detail = response.json().get("detail", response.text)
                    except Exception:
                        detail = response.text
                    st.error(f"Backend error: {detail}")
            except requests.RequestException as exc:
                st.error(f"Cannot reach FastAPI backend at {BACKEND_URL}: {exc}")

col1, col2 = st.columns([1.2, 1])
with col1:
    st.subheader("Document Preview")
    if st.session_state.document:
        st.markdown(format_html_preview(st.session_state.document), unsafe_allow_html=True)
    else:
        st.info("Your generated document will appear here.")

with col2:
    st.subheader("Edit Document")
    edited = st.text_area(
        "Editable content",
        value=st.session_state.document,
        height=520,
        label_visibility="collapsed"
    )
    if edited != st.session_state.document:
        st.session_state.document = edited

if st.session_state.document:
    st.divider()
    st.subheader("Export")
    logo_bytes = logo.getvalue() if logo else None
    txt = st.session_state.document.encode("utf-8")
    docx = format_docx(st.session_state.document, document_type, logo_bytes)
    pdf = format_pdf(st.session_state.document, document_type, logo_bytes)
    a, b, c = st.columns(3)
    with a:
        st.download_button("⬇️ Download TXT", txt, "legalease_document.txt", "text/plain", use_container_width=True)
    with b:
        st.download_button("⬇️ Download DOCX", docx, "legalease_document.docx",
                           "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                           use_container_width=True)
    with c:
        st.download_button("⬇️ Download PDF", pdf, "legalease_document.pdf", "application/pdf",
                           use_container_width=True)

if st.session_state.get("demo_mode"):
    st.warning("Demo mode: GEMINI_API_KEY is not configured. Add it to .env for real AI generation.")
else:
    if st.session_state.get("document"):
        st.caption(f"Model: {st.session_state.get('model', 'configured Gemini model')}")

st.caption("LegalEase produces draft legal text for review; it does not provide legal advice.")
